package com.syariefabdurrohman.modul2;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.zip.InflaterInputStream;

/**
 * Created by Syarief on 12-Sep-18.
 */

public class BodyPartFragment extends Fragment {
    public BodyPartFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState)
    {
        //inisialisasi
        View rootView = inflater.inflate(R.layout.body_part_layout_fragment, container, attachToRoot false);
        //
        ImageView imageView = (ImageView) rootView.findViewById(R.id.imageview_body_part_layout_fragment);

        ImageView.setImageResource(AndroidImageAssets.getHeads().get(0));
        return super.onCreateView(inflater, container, savedInstanceState);
    }
}
